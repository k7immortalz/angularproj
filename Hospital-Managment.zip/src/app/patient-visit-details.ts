export interface vital_signs {
    vital_signs:{
        height?:any;
        weight?:any;
        blood_pressure?:any;
        body_temp?:any;
        respiration_rate?:any;
      },
       diagnosis:[{
       diagnosis?:any;
        description?:any;
       }],
       Procedures:[{
        procedures?:any;
        description?:any;
      }],
      medication:[{
        medication?:any;
        dosage?:any;
        description?:any;
      }]
       
      
}
