import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  patientLogin = new FormGroup({
    Pemail: new FormControl(''),
    Ppassword: new FormControl(''),
  });
  employeeLogin = new FormGroup({
    Eemail: new FormControl(''),
    Epassword: new FormControl(''),
  });
  adminLogin = new FormGroup({
    Aemail: new FormControl(''),
    Apassword: new FormControl(''),
  });
  constructor() { }

  ngOnInit(): void {
  }
  onSubmitp(){
  
}
  onSubmite(){
  
}
onSubmita(){

}
}
