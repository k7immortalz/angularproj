export interface demographies{
    demographies:{
    first_name?:any;
    last_name?:any;
    date_of_birth?:any;
    age?:any;
    gender?:any;
    race?:any;
    ethinicity?:any;
    language?:any;
    email?:any;
    home_address?:any;
    contact_number?:any;
    emergency_contact_details:{
        first_name?:any;
        last_name?:any;
      relationship?:any;
      email_address?:any;
      contact?:any;
      address?:any;
      patient_portal_access?:any;
      },
      allergies:{
        type?:any;
        is_fatal?:any;
      }
    }
  }
  
 
  