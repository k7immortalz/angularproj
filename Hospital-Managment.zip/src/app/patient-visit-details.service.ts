import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
  
import {  Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { vital_signs} from './patient-visit-details';
@Injectable({
  providedIn: 'root'
})
export class PatientVisitDetailsService {
  private apiURL = "localhost:8080";
   
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  constructor(private httpClient: HttpClient) { }
  getAll(): Observable<vital_signs[]> {
    return this.httpClient.get<vital_signs[]>(this.apiURL)
    .pipe(
      catchError(this.errorHandler)
    )
  }
   
  create(post): Observable<vital_signs> {
    return this.httpClient.post<vital_signs>(this.apiURL, JSON.stringify(post), this.httpOptions)
    
    .pipe(
      catchError(this.errorHandler)
    )
  } 
  errorHandler(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    
    return throwError(errorMessage);
 }
}
