import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';
import { CustomvalidationService} from './customvalidation.service';
import { PatientVisitDetailsService } from '../patient-visit-details.service';
import { vital_signs} from '../patient-visit-details';
@Component({
  selector: 'app-patient-visit',
  templateUrl: './patient-visit.component.html',
  styleUrls: ['./patient-visit.component.css']
})
export class PatientVisitComponent implements OnInit {
PvisitForm: FormGroup;
submitted = false;
  constructor(private fb: FormBuilder,  private customValidator: CustomvalidationService, public postService: PatientVisitDetailsService) { }

  ngOnInit(): void {
     this.PvisitForm = this.fb.group({
      height: ['', [Validators.required]],
      weight: ['', [Validators.required]],
      Bpressure: ['', [Validators.required]],
      Btemperature:['', [Validators.required]],
      respiration:['', [Validators.required]],
      Diagnosis_Code:['', [Validators.required]],
      Diagnosis_Description:['', [Validators.required]],
      Diagnosis_Is_Depricated:['', [Validators.required]],
      Procedure_Code:['', [Validators.required]],
      Procedure_Description:['', [Validators.required]],
      Procedure_Is_Depricated:['', [Validators.required]],
      Drug_ID:['', [Validators.required]],
      Drug_Name:['', [Validators.required]],
      Drug_Generic_Name:['', [Validators.required]],
      Drug_Brand_Name:['', [Validators.required]],
      Drug_Form:['', [Validators.required]],
      Drug_Strength:['', [Validators.required]], 
      Drug_Description:['', [Validators.required]],
      
    }     
    );
  }
 get registerFormControl() {
    return this.PvisitForm.controls;
  }
  onSubmitp() {
    this.submitted = true;
    let basicSetup :vital_signs = {
        vital_signs:{
          height:this.PvisitForm.get('height').value,
          weight:this.PvisitForm.get('weight').value,
          blood_pressure:this.PvisitForm.get('Bpressure').value,
          body_temp:this.PvisitForm.get('Btemperature').value,
          respiration_rate:this.PvisitForm.get('respiration').value,
        },
         diagnosis:[{
         diagnosis:this.PvisitForm.get('Diagnosis_Code').value,
          description:this.PvisitForm.get('Diagnosis_Description').value,
         }],
         Procedures:[{
          procedures:this.PvisitForm.get('Procedure_Code').value,
          description:this.PvisitForm.get('Procedure_Description').value,
        }],
        medication:[{
          medication:this.PvisitForm.get('Drug_Name').value,
          dosage:this.PvisitForm.get('Drug_Strength').value,
          description:this.PvisitForm.get('Drug_Description').value,
        }]
    
     
    }
    if (this.PvisitForm.valid) {
      alert('Form Submitted succesfully!!!\n Check the values in browser console.');
      this.postService.create(basicSetup).subscribe(res => {
        console.log('Post created successfully!');
    })
    this.PvisitForm = this.fb.group(basicSetup);
    }
  }
}
