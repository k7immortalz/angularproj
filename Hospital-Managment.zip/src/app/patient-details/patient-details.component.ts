import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators,FormBuilder } from '@angular/forms';
import { CustomvalidationService} from './customvalidation.service';
import { PatientDetailsService } from '../patient-details.service';
import { demographies} from '../patient-details';
import {
  NgbCalendar,
  NgbDate,
  NgbDateStruct,
  NgbInputDatepickerConfig
} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.css']
})
export class PatientDetailsComponent implements OnInit {
  PdetailsForm: FormGroup;
  model: NgbDateStruct;
  submitted = false;
  constructor(config: NgbInputDatepickerConfig, calendar: NgbCalendar,private fb: FormBuilder,  private customValidator: CustomvalidationService, public postService: PatientDetailsService) {
    // customize default values of datepickers used by this component tree
    config.minDate = {year: 1900, month: 1, day: 1};
    config.maxDate = {year: 2099, month: 12, day: 31};

    // days that don't belong to current month are not visible
    config.outsideDays = 'hidden';

    // weekends are disabled
    config.markDisabled = (date: NgbDate) => calendar.getWeekday(date) >= 6;

    // setting datepicker popup to close only on click outside
    config.autoClose = 'outside';

    // setting datepicker popup to open above the input
    config.placement = ['top-left', 'top-right'];
   }

  ngOnInit(): void {
    this.PdetailsForm = this.fb.group({
      title: ['', [Validators.required]],
      firstName: ['', Validators.compose([Validators.required, this.customValidator.nameValidator()])],
      lastName: ['', Validators.compose([Validators.required, this.customValidator.nameValidator()])],
      dob: ['', [Validators.required]],
      age: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      race: ['', Validators.compose([Validators.required, this.customValidator.nameValidator()])],
      ethnicity : ['', Validators.compose([Validators.required, this.customValidator.nameValidator()])],
      languages : ['', Validators.compose([Validators.required, this.customValidator.nameValidator()])],      
      email: ['', [Validators.required, Validators.email]],
      address: ['', Validators.compose([Validators.required, this.customValidator.addressValidator()])],
      country: ['', [Validators.required]],
      phno: ['', Validators.compose([Validators.required, this.customValidator.phValidator()])],
      
        efirstName: ['', Validators.compose([Validators.required, this.customValidator.nameValidator()])],
        elastName: ['', Validators.compose([Validators.required, this.customValidator.nameValidator()])],
        relationship: ['', [Validators.required]],
        eemail: ['', [Validators.required, Validators.email]],
        ecountry: ['', [Validators.required]],
        ephno: ['', Validators.compose([Validators.required, this.customValidator.phValidator()])],
        eaddress:new FormControl(''),
        saddress:new FormControl(''),
        Pportal:new FormControl(''),
        allergies:new FormControl(''),
        allergyid:new FormControl(''),
        allergytype:new FormControl(''),
        allergyname:new FormControl(''),
        allergydescription:new FormControl(''),
        allergyc:new FormControl(''),
    }     
    );

  }

  get registerFormControl() {
    return this.PdetailsForm.controls;
  }
  onSubmitp() {
    this.submitted = true;
    let basicSetup :demographies = {
      demographies:{
      first_name:this.PdetailsForm.get('firstName').value,
      last_name:this.PdetailsForm.get('lastName').value,
      date_of_birth:this.PdetailsForm.get('dob').value,
      age:this.PdetailsForm.get('age').value,
      gender:this.PdetailsForm.get('gender').value,
      race:this.PdetailsForm.get('race').value,
      ethinicity:this.PdetailsForm.get('ethnicity').value,
      language:[this.PdetailsForm.get('languages').value],
      email:this.PdetailsForm.get('email').value,
      home_address:this.PdetailsForm.get('address').value,
      contact_number:this.PdetailsForm.get('phno').value,
      emergency_contact_details:{
        first_name:this.PdetailsForm.get('efirstName').value,
        last_name:this.PdetailsForm.get('elastName').value,
        relationship:this.PdetailsForm.get('relationship').value,
        email_address:this.PdetailsForm.get('eemail').value,
        contact:this.PdetailsForm.get('ephno').value,
        address:this.PdetailsForm.get('eaddress').value,
        patient_portal_access:this.PdetailsForm.get('Pportal').value,
      },
      allergies:{
        type:this.PdetailsForm.get('allergytype').value,
        is_fatal:this.PdetailsForm.get('allergies').value,
      },
    }
     
    }
    if (this.PdetailsForm.valid) {
      alert("submitted");
      this.postService.create(basicSetup).subscribe(res => {
        console.log('Post created successfully!');
    })
  }
  this.PdetailsForm = this.fb.group(basicSetup);
}
 status: boolean = false; 
clickEvent(){
     this.status = false;      
}
clickEvent1(){
     this.status = true;      
}
}
