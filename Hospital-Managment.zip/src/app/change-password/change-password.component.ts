import { Component, OnInit } from '@angular/core';
import { FormGroup,Validators,FormBuilder } from '@angular/forms';
import { CustomvalidationService} from './customvalidation.service';
@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  passwordForm: FormGroup;
  submitted = false;
  constructor(private fb: FormBuilder,  private customValidator: CustomvalidationService) { }

   ngOnInit(): void {
    this.passwordForm = this.fb.group({
      oldpassword: ['', [Validators.required]],
      password: ['', Validators.compose([Validators.required, this.customValidator.patternValidator()])],
      confirmPassword: ['', [Validators.required]],
        },
        {
          validator: this.customValidator.MatchPassword('password', 'confirmPassword'),
        }     
    );
  }
  get registerFormControl() {
    return this.passwordForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.passwordForm.valid) {
      alert('Form Submitted succesfully!!!\n Check the values in browser console.');
      console.table(this.passwordForm.value);
    }
  }

}
