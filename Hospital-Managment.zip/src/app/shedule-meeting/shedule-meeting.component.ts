import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shedule-meeting',
  templateUrl: './shedule-meeting.component.html',
  styleUrls: ['./shedule-meeting.component.css']
})
export class SheduleMeetingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
