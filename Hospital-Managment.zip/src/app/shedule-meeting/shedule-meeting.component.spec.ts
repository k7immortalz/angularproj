import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SheduleMeetingComponent } from './shedule-meeting.component';

describe('SheduleMeetingComponent', () => {
  let component: SheduleMeetingComponent;
  let fixture: ComponentFixture<SheduleMeetingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SheduleMeetingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SheduleMeetingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
