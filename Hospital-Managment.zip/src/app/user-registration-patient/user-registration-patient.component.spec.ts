import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserRegistrationPatientComponent } from './user-registration-patient.component';

describe('UserRegistrationPatientComponent', () => {
  let component: UserRegistrationPatientComponent;
  let fixture: ComponentFixture<UserRegistrationPatientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserRegistrationPatientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserRegistrationPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
