import { Component, OnInit } from '@angular/core';
import { FormGroup,Validators,FormBuilder } from '@angular/forms';
import { CustomvalidationService} from './customvalidation.service';
import {
  NgbCalendar,
  NgbDate,
  NgbDateStruct,
  NgbInputDatepickerConfig
} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-user-registration-patient',
  templateUrl: './user-registration-patient.component.html',
  styleUrls: ['./user-registration-patient.component.css']
})
export class UserRegistrationPatientComponent implements OnInit {
  profileForm: FormGroup;
  model: NgbDateStruct;
  submitted = false;
  constructor(config: NgbInputDatepickerConfig, calendar: NgbCalendar,private fb: FormBuilder,  private customValidator: CustomvalidationService) {
    // customize default values of datepickers used by this component tree
    config.minDate = {year: 1900, month: 1, day: 1};
    config.maxDate = {year: 2099, month: 12, day: 31};

    // days that don't belong to current month are not visible
    config.outsideDays = 'hidden';

    // weekends are disabled
    config.markDisabled = (date: NgbDate) => calendar.getWeekday(date) >= 6;

    // setting datepicker popup to close only on click outside
    config.autoClose = 'outside';

    // setting datepicker popup to open above the input
    config.placement = ['top-left', 'top-right'];
   }

  ngOnInit(): void {
    this.profileForm = this.fb.group({
      title: ['', [Validators.required]],
      firstName: ['', Validators.compose([Validators.required, this.customValidator.nameValidator()])],
      lastName: ['', Validators.compose([Validators.required, this.customValidator.nameValidator()])],
      email: ['', [Validators.required, Validators.email]],
      dob: ['', [Validators.required]],
      country: ['', [Validators.required]],
      phno: ['', Validators.compose([Validators.required, this.customValidator.phValidator()])],
      password: ['', Validators.compose([Validators.required, this.customValidator.patternValidator()])],
      confirmPassword: ['', [Validators.required]],
        },
        {
          validator: this.customValidator.MatchPassword('password', 'confirmPassword'),
        }     
    );
  }
  get registerFormControl() {
    return this.profileForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    if (this.profileForm.valid) {
      alert('Form Submitted succesfully!!!\n Check the values in browser console.');
      console.table(this.profileForm.value);
    }
  }
}
