import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CreatecontactsComponent } from './createcontacts/createcontacts.component';
import { CreatelabelComponent } from './createlabel/createlabel.component';
import { ContactservicesService } from './contactservices.service';

import { MatTableDataSource } from '@angular/material';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  ELEMENT_DATA: [] = [];
  ref: any
  labelRef: any;
  searchText: any;
  data: any
  labelArray = [];
  mobileQuery: MediaQueryList;
  subscription: Subscription;
  private _mobileQueryListener: () => void;
  constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher, public dialog: MatDialog, private labelService: ContactservicesService) {
    this.labelArray = this.labelService.getLabelArray();
    console.log("check",this.labelArray)
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);

  }
  dataSource = new MatTableDataSource<[]>(this.ELEMENT_DATA);
  ngOnInit() {

  }

  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }

  shouldRun = [/(^|\.)plnkr\.co$/, /(^|\.)stackblitz\.io$/].some(h => h.test(window.location.host));


  createAccount(): void {
    const dialogRef = this.dialog.open(CreatecontactsComponent, {
      width: '750px',
      height: '400px',
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    
      console.log(result);
    });
  }

  createLabel(): void {
    const dialogRef = this.dialog.open(CreatelabelComponent, {
      width: '350px',
      height: '200px',
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
    });
  }

  editLabel(labelData) {
    const dialogRef = this.dialog.open(CreatelabelComponent, {
      width: '350px',
      height: '200px',
      data: {
        label: labelData,
        isedit: true
      }
    });
    dialogRef.afterClosed().subscribe(response => {
      console.log(response);
      console.log('The dialog was closed');

    });
  }

  deleteLabel(dellabel) {
    const index: number = this.labelArray.indexOf(dellabel);
    if (index !== -1) {
      this.labelArray.splice(index, 1);
      this.labelService.deleteLabels(dellabel.id).subscribe(
        response => {
          console.log("deletelabel", response);
        })
    }
  }


  navClick(label) {
    console.log(label);
    let labelView=[];
    this.labelRef = this.labelService.getLabelContactById(label);
     console.log("thisanjaysss", this.labelRef);
  }


  applyFilter(filterValue: string) {
    let search = [];
    console.log("filtervalue", filterValue)
    this.searchText = this.labelService.getSearch(filterValue).subscribe
      (response => {
        Object.keys(response).forEach(key => {
          const arr = {
            Fname: response[key]['Fname'],
            email: response[key]['email'],
            phoneno: response[key]['phoneno']
          }
          search.push(arr);
          console.log("search", search);
          this.labelService.setSearchMethod(search);
        });
      })
    }
}
