import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatecontactsComponent } from './createcontacts.component';

describe('CreatecontactsComponent', () => {
  let component: CreatecontactsComponent;
  let fixture: ComponentFixture<CreatecontactsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatecontactsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatecontactsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
