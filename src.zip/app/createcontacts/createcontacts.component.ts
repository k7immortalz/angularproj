import { Component, OnInit ,Inject} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { NgForm } from '@angular/forms';

import { ContactservicesService} from '../contactservices.service';

@Component({
  selector: 'app-createcontacts',
  templateUrl: './createcontacts.component.html',
  styleUrls: ['./createcontacts.component.css']
})

export class CreatecontactsComponent implements OnInit {

  constructor( public dialogRef: MatDialogRef<CreatecontactsComponent>,public contactSave: ContactservicesService,) {
   }
   Fname:any;
   Lname:any;
   company:any;
   jobtitle:any;
   email:any;
   phone:any;
   notes:any;

   formsubmit(formData: NgForm) {
    console.log(formData.value);
    this.contactSave.save(formData.value).subscribe(
      (response) => {
        this.contactSave.setContacts(response['name']);
        console.log("form",response);
      
      },
      (error) => console.log(error)
    );
    formData.reset();
}

  ngOnInit() {
  }
  onClose(): void {
    console.log(this.dialogRef); 
    this.dialogRef.close(); 
    }
}
