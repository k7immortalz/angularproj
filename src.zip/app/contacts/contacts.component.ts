import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { ContactservicesService } from '../contactservices.service';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DeletemenuComponent } from '../deletemenu/deletemenu.component';
import { MatMenuTrigger } from '@angular/material'
import { EditcontactComponent } from '../editcontact/editcontact.component';
import { Subscription } from 'rxjs';


export interface PeriodicElement {
  Fname: string;
  email: string;
  phoneno: number;
  id: string;
}

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class ContactsComponent implements OnInit {
  ELEMENT_DATA: PeriodicElement[] = [];
  Fname: string;
  email: string;
  phone: number;
  labelArrays: string[] = [];
  labArr: any
  labelcontacts: any;
  tableRowId: any;
  labelRowId: any;
  searchInput: any;
  subscription: Subscription;
  final: any;
  starAccountPinned= [];
  pinned: boolean;

  constructor(private contactservice: ContactservicesService, public dialog: MatDialog) {

    this.labelArrays = this.contactservice.getLabelArray();
    this.contactservice.getTableArray().subscribe(
      (response) => {
        let fData = [];
        Object.keys(response).forEach(key => {
          console.log('data', key);
          const data = {
            // FnameU:response[key]['Fname'].charAt(0),
            Fname: response[key]['Fname'],
            email: response[key]['email'],
            phone: response[key]['phone'],
            id:key
          }
          fData.push(data);
          });
        this.displayedColumns = ['select', 'Fname', 'email', 'phone', 'star'];
        console.log('fData', fData);
        this.dataSource.data = fData;
      }
    )
  }

  ngOnInit() {
    this.subscription = this.contactservice.getSearchMethod().subscribe
      (search => {
        this.dataSource.data = search;
      });
  }
  idrow(row: any) {
    this.tableRowId = row;
    console.log(row, "row");
  }

  displayedColumns = ['select', 'Fname', 'email', 'phone', 'star'];
  dataSource = new MatTableDataSource<PeriodicElement>(this.ELEMENT_DATA);
  selection = new SelectionModel<PeriodicElement>(true, []);

/** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }
  @ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
  onOpenMenu(menu: any): void {
    console.log(menu);
  }
  closeMyMenu() {
    this.trigger.closeMenu();
    console.log('close')
  }


  deleteaccount(row): void {
    const dialogRef = this.dialog.open(DeletemenuComponent, {
      width: '300px',
      height: '200px',
    });
    dialogRef.afterClosed().subscribe(
      (response) => {
        console.log(row, "roooowwwwwwwwww", this.selection.selected)
        this.selection.selected.forEach(item => {
          let index: number = (this.dataSource.data).findIndex(d => d === item);
          console.log(item, "itemitemitem");
          (this.dataSource.data).splice(index, 1);
          this.contactservice.deleteRow(item.id).subscribe(
            response => {
              console.log("response", response)
            }
          )
          console.log((this.dataSource.data), 'response123', item.id);
          this.dataSource = new MatTableDataSource<PeriodicElement>(this.dataSource.data);
        })
      }

    );
    console.log('The dialog was closed');
    console.log("response", row);
}

 editAccount(element): void {
    const dialogRef = this.dialog.open(EditcontactComponent, {
      width: '750px',
      height: '400px',
      data: element
    });
    dialogRef.afterClosed().subscribe(
      response => {
      console.log(response);
      this.contactservice.updateAccount(response);
      console.log('The dialog was closed');
   })
    }

  rowid(addLabel: any) {
    this.labelRowId = addLabel;
    console.log(addLabel, "addLabel");
    this.contactservice.getLabelid(this.labelRowId['id'], this.tableRowId).subscribe((data: any) => {
      console.log("hiisssssss", data)
      this.final = data;
    }, (error) => {
      console.log(error);
    }, () => {
      console.log("ggggggggggkk", this.final);
      this.final['contactDetails'].push(this.tableRowId)
      this.contactservice.postContactArray(this.labelRowId['id'], this.final)
    })
  }
}


