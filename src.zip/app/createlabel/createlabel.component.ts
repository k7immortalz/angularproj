import { Component, OnInit ,Inject} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { NgForm } from '@angular/forms';
import { ContactservicesService } from '../contactservices.service';

@Component({
  selector: 'app-createlabel',
  templateUrl: './createlabel.component.html',
  styleUrls: ['./createlabel.component.css']
})
export class CreatelabelComponent implements OnInit {
  label:any;
  isEdit = false;
  editID='';
  edit:any;
  labelArray:[];
  constructor(public dialogRef: MatDialogRef<CreatelabelComponent>,@Inject(MAT_DIALOG_DATA) private data, public labels: ContactservicesService) {
    console.log('data', this.data);
     }
   
  ngOnInit() {
    if(this.data['isedit']){
      this.isEdit = true
      this.label = this.data['label']['label'];
      this.editID = this.data['label']['id'];
      console.log('data', this.data);
    }else{
      this.isEdit = false;
    }
    // console.log(this.isEdit,"this.data['isedit']this.data['isedit']")
  }
    formsubmits(forms: NgForm) {
    console.log(forms.value);
    if(this.isEdit){
      const data = {
        id: this.editID,
        label:forms.value['label']
      }
       this.labels.updateLabel(data);
        }
     else{
      this.labels.saveLabel(forms.value).subscribe(
        (response)=>
        {
          this.labels.addLabel(response['name']);
          console.log("response",response);
        },
        )
    }
    
    forms.reset();}
   

 onClose(): void {
    console.log(this.dialogRef); 
    this.dialogRef.close(); 
    }
}
