import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ContactservicesService {

  labelRef: any;
  Fname: string;
  Lname: any;
  company: any;
  jobTitle: any;
  email: any;
  phoneno: number;
  notes: any;
  ELEMENT_DATA = [];
  dataSource = [];
  label: any;
  labelArray = [];
  labelArrays = [];
  starAccountPinned=[];
  pinned: boolean;

  private searchInputText = new Subject();
  constructor(private http: HttpClient) { }
  save(formData) {
    console.log(formData);
   
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    return this.http.post('https://preethi-contact.firebaseio.com/contacts.json', formData, { headers: headers });
  }


  setContacts(id) {
    const headers = new HttpHeaders({ 'Content-type': 'application/json' });
    this.http.get('https://preethi-contact.firebaseio.com/contacts/' + id + '.json',{ headers: headers }).subscribe(
      response => {
          this.dataSource.push({ 'Fname': response['Fname'], 'email': response['email'], 'phoneno': response['phoneno'] , 'id': id})
          console.log("kkkkkkk", this.dataSource);
        });
        
      }

  getTableArray() {
    const headers = new HttpHeaders({ 'Content-type': 'application/json' });
    return this.http.get('https://preethi-contact.firebaseio.com/contacts.json', { headers: headers });
  }

  deleteRow(id) {
    console.log(id, "lllllllllll")
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    return this.http.delete('https://preethi-contact.firebaseio.com/contacts/' + id + '.json', { headers: headers })
  }


  updateAccount(formData) {
    console.log('formData', formData);
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    this.http.put('https://preethi-contact.firebaseio.com/contacts/' + formData.id + '.json', formData, { headers: headers }).subscribe(
      response => {
        console.log('response', response);
      }
    );
  }

  saveLabel(ok: any) {

    ok.contactDetails = [{ Fname: "", email: "", phoneno: "" }]
    console.log("hi", ok);
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    return this.http.post('https://preethi-contact.firebaseio.com/Label.json', ok, { headers: headers });
  }

  getLabelArray() {
    let array = [];
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    this.http.get('https://preethi-contact.firebaseio.com/Label.json', { headers: headers }).subscribe(
      response => {
        Object.keys(response).forEach(key => {
          const arr = {
            label: response[key]['label'],
            id: key,
          }
          array.push(arr);
        });
      })
    console.log("res", array);
    return array;

  }

  getLabel() {
    let array = [];
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    this.http.get('https://preethi-contact.firebaseio.com/Label.json', { headers: headers }).subscribe(
      response => {
        Object.keys(response).forEach(key => {
          const arr = {
            label: response[key]['label'],
            id: key,
            contactArray: ['contactArray']
         }
        array.push(arr);
       });
        console.log("res1", array);
        console.log("res", response);
      })

    this.labelArray = array;
    return array;
  }

  addLabel(id) {
    let lab = []
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    this.http.get('https://preethi-contact.firebaseio.com/Label/' + id + '.json', { headers: headers }).subscribe(
      (response) => {
        console.log("resssss", this.labelArray);
        console.log("push", response);
        this.labelArray.filter((res) => {
          lab.push(res.label)
        })
        // console.log(response['label'],"ooooooooo",lab)
        if (!(lab.includes(response['label']))) {
          Object.keys(response).forEach(key => {
            this.labelArray.push({ 'id': id, 'label': response['label'] })
          })
        }

      })
  }

  updateLabel(forms) {
    let labs = [];
    console.log('formDatas', forms);
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    this.http.put('https://preethi-contact.firebaseio.com/Label/' + forms.id + '.json', forms, { headers: headers }).subscribe(
      response => {
        console.log('response', response, forms);
        console.log('this.labelArray', this.labelArray);
        const index = this.labelArray.findIndex(label => label.id == forms.id)
        this.labelArray[index]['label'] = forms.label;
      }
    )
  }

  postContactArray(id, data) {
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    this.http.put('https://preethi-contact.firebaseio.com/Label/' + id + '.json', data, { headers: headers }).subscribe(
      response => {
        console.log('response123', response);
      }
    )
  }
  deleteLabels(id) {
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    return this.http.delete('https://preethi-contact.firebaseio.com/Label/' + id + '.json', { headers: headers })
  }

  getContactLabel() {
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    return this.http.get('https://preethi-contact.firebaseio.com/contacts.json', { headers: headers })
  }



  getContactDetails(contactID: any) {
    console.log(contactID)
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    return this.http.get('https://preethi-contact.firebaseio.com/Label/' + contactID + '.json', { headers: headers })
  }

  getLabelid(id: any, tableRowId: any) {
    console.log(id, "ggggggg", tableRowId);
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    return this.http.get('https://preethi-contact.firebaseio.com/Label/' + id + '.json', { headers: headers })
  }
 
  getLabelContactById(label) {
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    return this.http.get('https://preethi-contact.firebaseio.com/Label/' + label.id + '.json', { headers: headers }).subscribe(
      response => {
        console.log(response, 'res------>');

      })
  }

  getLabelView() {
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    return this.http.get('https://preethi-contact.firebaseio.com/Label.json', { headers: headers })
  }

  getSearch(filterValue) {
   return this.http.get('https://preethi-contact.firebaseio.com/contacts.json?orderBy="Fname"&startAt="' + filterValue + '"')
  }

  public setSearchMethod(search): void {
    this.searchInputText.next(search);
  }

  public getSearchMethod(): Observable<any> {
    return this.searchInputText.asObservable();
  }

  getStarredData(formData){
    const headers = new HttpHeaders({ 'Content-type': 'application/json' })
    return this.http.get('https://preethi-contact.firebaseio.com/contacts/' + formData.id +'.json',{ headers: headers })

  }

  
}
