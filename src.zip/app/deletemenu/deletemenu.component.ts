import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ContactservicesService } from '../contactservices.service';
@Component({
  selector: 'app-deletemenu',
  templateUrl: './deletemenu.component.html',
  styleUrls: ['./deletemenu.component.css']
})
export class DeletemenuComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<DeletemenuComponent>) {

   }

  ngOnInit() {
  }
  onClose(): void {
    console.log(this.dialogRef.disableClose); 
    this.dialogRef.close(); 
    }

    deleteacc(){
 
      

      }
      

    }


