import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { ContactservicesService } from '../contactservices.service';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DeletemenuComponent } from '../deletemenu/deletemenu.component';
import { MatMenuTrigger } from '@angular/material'
import { EditcontactComponent } from '../editcontact/editcontact.component';
import { CreatecontactsComponent } from '../createcontacts/createcontacts.component';
import { Subscription } from 'rxjs';
export interface PeriodicElement {
  Fname: string;
  email: string;
  phoneno: number;
  id: string;
}

@Component({
  selector: 'app-directory',
  templateUrl: './directory.component.html',
  styleUrls: ['./directory.component.css']
})
export class DirectoryComponent implements OnInit {

  ELEMENT_DATA: PeriodicElement[] = [];
  Fname: string;
  email: string;
  phone: number;
  count: any;
  subscription: Subscription;
  constructor(private contactservice: ContactservicesService, public dialog: MatDialog) {
    this.contactservice.getTableArray().subscribe(
      (response) => {
        let fData = [];
        Object.keys(response).forEach(key => {
          console.log('data', key);
          const data = {
            Fname: response[key]['Fname'],
            email: response[key]['email'],
            phone: response[key]['phone'],
            id:key
          }
          fData.push(data);
        });

        this.displayedColumns = ['select', 'Fname', 'email', 'phone', 'star'];
        console.log('fData', fData);
        this.dataSource.data = fData;
        this.count = fData.length
        //  localStorage.setItem('kp',JSON.stringify(fData))
      }
    )
  }

  ngOnInit() {
    this.subscription = this.contactservice.getSearchMethod().subscribe
      (search => {
        this.dataSource.data = search;
      });
  }
  // data = Object.assign( ELEMENT_DATA);
  displayedColumns = ['select', 'Fname', 'email', 'phone', 'star'];
  dataSource = new MatTableDataSource<PeriodicElement>(this.ELEMENT_DATA);
  selection = new SelectionModel<PeriodicElement>(true, []);



  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }
  @ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
  onOpenMenu(menu: any): void {
    console.log(menu);
  }
  closeMyMenu() {
    this.trigger.closeMenu();
    console.log('close')
  }


  deleteaccount(row): void {
    const dialogRef = this.dialog.open(DeletemenuComponent, {
      width: '300px',
      height: '200px',
    });
    dialogRef.afterClosed().subscribe(
      (response) => {
        console.log(row, "roooowwwwwwwwww", this.selection.selected)
        this.selection.selected.forEach(item => {
          let index: number = (this.dataSource.data).findIndex(d => d === item);
          console.log(item, "itemitemitem");

          (this.dataSource.data).splice(index, 1);
          this.contactservice.deleteRow(item.id).subscribe(
            response => {
              console.log("response", response)
            }
          )
          console.log((this.dataSource.data), 'response123', item.id);
          this.dataSource = new MatTableDataSource<PeriodicElement>(this.dataSource.data);

        })
      }

    );
    // this.selection = new SelectionModel<PeriodicElement>(true, []);

    console.log('The dialog was closed');
    console.log("response", row);


  }


  editAccount(element): void {
    const dialogRef = this.dialog.open(EditcontactComponent, {
      width: '750px',
      height: '400px',
      data: element
    });
    dialogRef.afterClosed().subscribe(
      response => {
        
        console.log(response);
        this.contactservice.updateAccount(response);
        console.log('The dialog was closed');
        // response=this.dataSource.data
        // this.dataSource = new MatTableDataSource<PeriodicElement>(this.dataSource.data);
        console.log(response);
      })
  }



}

