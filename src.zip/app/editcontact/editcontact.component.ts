import { Component, OnInit ,Inject} from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-editcontact',
  templateUrl: './editcontact.component.html',
  styleUrls: ['./editcontact.component.css']
})
export class EditcontactComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<EditcontactComponent>,@Inject(MAT_DIALOG_DATA) public data: any) { 
    console.log("editdata",data);
  }

  ngOnInit() {
  }
  onClose(): void {
    console.log(this.dialogRef.disableClose); 
    this.dialogRef.close(); 
    }



}
