import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { ContactservicesService } from '../contactservices.service';
import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DeletemenuComponent } from '../deletemenu/deletemenu.component';
import { MatMenuTrigger } from '@angular/material'
import { EditcontactComponent } from '../editcontact/editcontact.component';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Params } from '@angular/router';

export interface PeriodicElement {
  Fname: string;
  email: string;
  phoneno: number;
  id: string;
}
export interface PeriodicElement {
  Fname: string;
  email: string;
  phoneno: number;
  id: string;
}

@Component({
  selector: 'app-label-view',
  templateUrl: './label-view.component.html',
  styleUrls: ['./label-view.component.css']
})


export class LabelViewComponent implements OnInit {
  ELEMENT_DATA: PeriodicElement[] = [];
  Fname: string;
  email: string;
  phoneno: number;
  fData1 = [];
  labelArrays: string[] = [];
  contacts: any[]
  labArr: any
  labelId: any;
  tableRowId: any;
  labelRowId: any;
  finalResponse: any;

  subscription: Subscription
  constructor(private contactService: ContactservicesService, public dialog: MatDialog, public activateroute: ActivatedRoute) {
    this.labelArrays = this.contactService.getLabelArray();
  }
  ngOnInit() {
    this.subscription = this.activateroute.params.subscribe((param: Params) => {

      console.log("parameter changed");

      this.labelId = param.labelId;
      console.log("contactssss", this.labelId)
      this.contactService.getContactDetails(this.labelId).subscribe((data: any[]) => {

        //console.log("pree",data['contactDetails'].splice(1,1))
        data['contactDetails'].splice(0, 1);
        const fData1 = data['contactDetails'];
        console.log('data', data)
        console.log('this.fData1', fData1)
        let fData = [];
        Object.values(fData1).forEach(key => {
          console.log('data', key);
          const data1 = {
            Fname: key['Fname'],
            email: key['email'],
            phoneno: key['phoneno'],
          }
          fData.push(data1);
          console.log("contact", data1);
        });
        this.displayedColumns = ['select', 'Fname', 'email', 'phoneno', 'star'];
        console.log('fData', fData);
        this.dataSource.data = fData;
      }, (error) => {
        console.log(error);
      })
    })
  }
  displayedColumns = ['select', 'Fname', 'email', 'phoneno', 'star'];
  dataSource = new MatTableDataSource<PeriodicElement>(this.ELEMENT_DATA);
  selection = new SelectionModel<PeriodicElement>(true, []);

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }
  @ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
  onOpenMenu(menu: any): void {
    console.log(menu);
  }
  closeMyMenu() {
    this.trigger.closeMenu();
    console.log('close')
  }


  deleteaccount(row): void {
    const dialogRef = this.dialog.open(DeletemenuComponent, {
      width: '300px',
      height: '200px',
    });
    dialogRef.afterClosed().subscribe(
      (response) => {
        console.log(row, "roooowwwwwwwwww", this.selection.selected)
        this.selection.selected.forEach(item => {
          let index: number = (this.dataSource.data).findIndex(d => d === item);
          console.log(item, "itemitemitem");

          (this.dataSource.data).splice(index, 1);
          this.contactService.deleteRow(item.id).subscribe(
            response => {
              console.log("response", response)
            }
          )
          console.log((this.dataSource.data), 'response123', item.id);
          this.dataSource = new MatTableDataSource<PeriodicElement>(this.dataSource.data);

        })
      }

    );


    console.log('The dialog was closed');
    console.log("response", row);
  }


  editAccount(element): void {
    const dialogRef = this.dialog.open(EditcontactComponent, {
      width: '750px',
      height: '400px',
      data: element
    });
    dialogRef.afterClosed().subscribe(
      response => {
        // this.data = response;
        console.log(response);
        this.contactService.updateAccount(response);
        console.log('The dialog was closed');
        console.log(response);
      })
  }
}

