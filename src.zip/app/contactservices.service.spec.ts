import { TestBed } from '@angular/core/testing';

import { ContactservicesService } from './contactservices.service';

describe('ContactservicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ContactservicesService = TestBed.get(ContactservicesService);
    expect(service).toBeTruthy();
  });
});
