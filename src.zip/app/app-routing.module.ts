import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactsComponent } from './contacts/contacts.component';
import { DirectoryComponent } from './directory/directory.component';
import{ LabelViewComponent} from './label-view/label-view.component'
import { AppComponent } from './app.component';
const routes: Routes = [
{path:'contacts',component:ContactsComponent},
{path:'directory',component:DirectoryComponent},
{path:'labels',component:LabelViewComponent},
{path:'labels/:labelId', component:LabelViewComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  })
export class AppRoutingModule {
  
 }
export const routingcomponent=[ContactsComponent,DirectoryComponent,LabelViewComponent];